#include<bits/stdc++.h>
using namespace std;
int dis[20010]={0};
int visited[20010]={0};
int bfs(vector<int>G[20010],int start)
{
    queue<int>Q;
    int sum1=0,sum2=1;
    Q.push(start);
    dis[start]=1;
    while(!Q.empty()){
        int u=Q.front();
        visited[u]=1;
        Q.pop();
        for(int i=0; i<G[u].size(); i++){
            int v=G[u][i];
            if(visited[v]==3){
                 Q.push(v);
                 visited[v]=1;
                 if(dis[u]==1){
                    dis[v]=2;
                    sum1++;
                 }
                 else{
                    dis[v]=1;
                    sum2++;
                 }
            }
        }
    }
    return max(sum1,sum2);
}
int main()
{
    int node,t,x,y,start,endd,edge,sum=0;
    cin>>t;
    for(int a=1; a<=t; a++){
        vector<int>G[20010];
        dis[20010]={0};
        visited[20010]={0};
        sum=0;
        cin>>edge;
        for(int i=0; i<edge; i++){
            cin>>x>>y;
            G[x].push_back(y);
            G[y].push_back(x);
            visited[x]=3;
            visited[y]=3;
        }
        for(int j=1; j<20010; j++){
            if(visited[j]==3){
                sum=sum+bfs(G,j);
            }
        }
        cout<<"Case "<<a<<": "<<sum<<endl;
    }
    return 0;
}
