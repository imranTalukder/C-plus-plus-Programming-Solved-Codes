#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m;
    cin>>m;
    m=m-50;
    if(m<0){
        cout<<"Can't reach to market."<<endl;
    }
    else if(m<2695){
        cout<<"Reach but can't buy."<<endl;
    }

    else if(m<2990){
        cout<<"You are able to buy Vault VL1020."<<endl;
    }
     else if(m<3635){
        cout<<"You are able to buy Vault VL1010."<<endl;
    }
    else if(m<3990){
        cout<<"You are able to buy Ashton Av100."<<endl;
    }
    else if(m<4038){
        cout<<"You are able to buy Vault VL1040."<<endl;
    }
    else if(m<6200){
        cout<<"You are able to buy Ashton Av142Nat."<<endl;
    }
    else if(m<6865){
        cout<<"You are able to buy Stagg VN."<<endl;
    }
     else if(m<20930){
        cout<<"You are able to buy Granada NV888."<<endl;
    }
    else if(m>=20930){
        cout<<"You are able to buy Hofner AS-060."<<endl;
    }

    return 0;
}
