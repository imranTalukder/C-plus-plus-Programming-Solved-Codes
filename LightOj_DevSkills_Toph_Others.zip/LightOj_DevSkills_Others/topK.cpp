#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n,m,a[200][200],b,ob,maxx[1000]={0};
    cin>>t;
    for(int i=1; i<=t; i++){
        cin>>n>>m;
        for(int j=0; j<n; j++){
            for(int k=0; k<m; k++){
                cin>>a[i][j];
            }
        }
        cin>>b>>ob;
        for(int j=0; j<n; j++){
            int sum=0;
            int too=ob;
            for(int h=0; h<m; h++){
                if(a[j][h]==1 && too>0){
                    sum++;
                    too--;
                    maxx[i]=sum;
                }
            }
        }
        int deg=0;
        sort(maxx,maxx+n);
        for(int k=n-1; k>n-b; k--){
            deg+=maxx[k];
        }
        cout<<deg<<endl;
    }
    return 0;
}
