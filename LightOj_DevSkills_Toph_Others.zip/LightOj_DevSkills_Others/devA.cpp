#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    ull t,a,b,sum,num,n,x,p=0;
    string m;

    cin>>t;
    for(int i=1; i<=t; i++){
        cin>>a;
        cin>>b;
        cin>>num;
        p=0;
        sum=a;
        while(num--){
            cin>>m>>x;

            if(m=="out"){
                sum=sum-x;
                if(a<x){
                    p=1;
                }
            }
            else if(m=="in"){
                sum=sum+x;
            }
        }
        if(sum==b && p==0){
            cout<<"yes"<<endl;
        }
        else{
            cout<<"no"<<endl;
        }
    }

    return 0;
}

