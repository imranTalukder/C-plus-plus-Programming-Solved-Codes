#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[5]={'4','1','3','2','5'},key;
    cout<<sizeof(a)/4<<endl;
    map<char, int>imran;
    imran['a']=10;
    imran['b']=20;
    cout<<imran['a']<<" "<<imran['b']<<endl;
    imran.insert(pair <char, int> ('d',30));
    cout<<imran['d'];
    return 0;
}
