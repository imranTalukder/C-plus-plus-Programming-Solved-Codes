#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long N,M,countt=0,i,fib,temp;
    cin>>N>>M;
    if(N>M){
        temp=M;
        M=N;
        N=temp;
    }
    for(i=N; i<=M; i++){
        fib=(i-1)%3;
        if(fib==0){
            countt++;
        }
    }
    cout<<M-N-countt+1<<"  "<<countt<<endl;
    return 0;
}
