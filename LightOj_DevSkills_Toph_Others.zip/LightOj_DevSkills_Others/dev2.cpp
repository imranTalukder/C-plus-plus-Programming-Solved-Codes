#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    while(cin>>s){
        int z;
        z=s.length();
        for(int i=0; i<z-1; i++){
            cout<<"9";
        }
        cout<<"8";
        for(int i=0; i<z-1; i++){
            cout<<"0";
        }
        cout<<"1"<<endl;
    }
    return 0;
}
