#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m,n,f=0,fn=0,row,column,c=0,countt=0;
    char k[100][100];
    cin>>m>>n;
    for(int i=0; i<m; i++){
        c=0;
        for(int j=0; j<n; j++){
            cin>>k[i][j];
            if(k[i][j]=='B'){
                countt++;
            }
            if(k[i][j]=='B' && f==0){
                f=i+1;
            }
            else if(k[i][j]=='B' && f>0 && c==0){
                fn=i+1;
                c=1;
            }
        }
    }
    if(fn>0 && f>>0){
        row=fn-f+1;
    }
    else{
        row=fn-f;
    }
    f=0;
    fn=0;
    for(int i=0; i<m; i++){
        c=0;
        for(int j=0; j<n; j++){
            if(k[j][i]=='B' && f==0){
                f=i+1;
            }
            else if(k[j][i]=='B' && f>0 && c==0){
                fn=i+1;
                c=1;
            }
        }
    }
    if(fn>0 && f>>0){
        column=fn-f+1;
    }
    else{
        column=fn-f;
    }
    f=max(row,column);
    c=max(m,n);
    if(f>c){
        cout<<"-1"<<endl;
    }
    else if(countt==0){
        cout<<"1"<<endl;
    }
    else{
        cout<<f*f-countt<<endl;
    }

    return 0;
}
