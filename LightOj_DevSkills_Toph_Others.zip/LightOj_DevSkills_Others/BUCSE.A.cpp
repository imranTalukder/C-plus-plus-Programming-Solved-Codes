#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long n,p,value,countt=0,i,sum=0,k=-1;
    cin>>n>>p;
    for(i=1; i<=n; i++){
        cin>>value;
        if(value==p){
            countt++;
            sum=sum+i;
        }
        if(k>value){
            countt=0;
        }
        k=value;
    }
    if(countt==0){
        cout<<"Impossible"<<endl;
        return 0;
    }
    cout<<sum/countt<<endl;

    return 0;
}
