#include<stdio.h>
#include<math.h>
int main()
{
    int N,s,M,i,j,A[10005],t,f,k,p;
	while(scanf("%d", &N)!=EOF){
	for(k=0;k<N;k++){
		scanf("%d", &A[k]);
	}
		scanf("%d",&M);
	int max=2000008;
	for(t=0;t<N;t++){
		for(f=t+1;f<N;f++){
			s=A[t]+A[f];
			if(s==M){
				p=abs(A[t]-A[f]);
                    if(p<=max){
						max=p;
				        i=A[t];
				        j=A[f];
                    }
			}
		}
	}
	if(i<j){
		printf("Peter should buy books whose prices are %d and %d.\n",i,j);
	}
	else {
				printf("Peter should buy books whose prices are %d and %d.\n",j,i);
	}
	printf("\n");

	}
	return 0;
}
