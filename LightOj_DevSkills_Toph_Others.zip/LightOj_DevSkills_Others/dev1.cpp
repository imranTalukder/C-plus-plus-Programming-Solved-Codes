#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    int t, cnt=0,p=1,l;
    cin>>t;

    for(int j=1; j<=t; j++){
        cin>>l;
        cin>>s;
        cnt=0;
        int p=0;
        for(int i=0; i<l; i++){

            if(s[i]=='a' || s[i]=='e' || s[i]=='i' || s[i]=='o' || s[i]=='u'){
                if(p==0){
                    cnt++;
                    p=1;
                }
            }
            else{
                p=0;
            }
        }
        cout<<"Case "<<j<<": "<<cnt<<endl;
    }
    return 0;
}
