#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    int t,n;
    double p,sum,val;
    cin>>t;
    while(t--){
        cin>>n;
        sum=1.0;
        for(int i=0; i<n; i++){
            cin>>val;
            sum=sum*val;
        }
        sum=1.0-sum;
        printf("%.5lf\n",sum);
    }

    return 0;
}

