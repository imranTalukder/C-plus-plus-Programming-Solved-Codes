#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long a[100000],n,i,j;
    cin>>n;
    for(j=0; j<n; j++){
        cin>>a[j];
    }
    for(i=0; i<n; i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
