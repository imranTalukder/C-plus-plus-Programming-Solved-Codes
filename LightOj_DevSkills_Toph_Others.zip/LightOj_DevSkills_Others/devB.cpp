#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    int t,len;
    string m;
    cin>>t;
    while(t--){
        cin>>len;
        int cnt=0;
        cin>>m;
        for(int i=0; i<len-1; i++){
            for(int j=i+2; j<len-1; j++){
                if(m[i]==m[j+1] && m[i+1]==m[j]){
                    cnt++;
                }
            }
        }
        cout<<cnt<<endl;
    }

    return 0;
}

