#include<bits/stdc++.h>
using namespace std;
int N;
vector<int>connected[305];
bool reached[305];
int parent[305];
void bfs(int start, int target){
    if(start==target){
        cout<<start<<endl;
        return;
    }
    for(int i=0; i<305; i++){
        parent[i]=-1;
    }
    queue<int>currentq;
    currentq.push(start);
    while(!currentq.empty()&& parent[target]==-1){
        int current=currentq.front();
        currentq.pop();
        for(int next: connected[current]){
            if(parent[next]==-1){
                parent[next]=current;
                currentq.push(next);
            }
        }
    }
    if(parent[target]==-1){
        cout<<"connection impossible"<<endl;
    }
    else{
        stack<int>reversed;
        int n=target;
        while(n !=start){
            reversed.push(n);
            n=parent[n];
        }
        cout<<start;
        while(!reversed.empty()){
            int top=reversed.top();
            reversed.pop();
            cout<<' '<<top;
        }
        cout<<endl;
    }
}
int main(){
    char garbage;
    string line;
    while(cin>>N && N){
        for(int i=0; i<305; i++){
            connected[i].clear();
        }
        for(int i=0; i<N; i++){
            int router;
            cin>>router;
            getline(cin,line);
            stringstream ss(line);
            int connectedto;
            while(ss>>garbage>>connectedto){
                connected[router].push_back(connectedto);
            }
        }
        int m;
        cin>>m;
        cout<<"-----"<<endl;
        while(m--){
            int start, target;
            cin>>start>>target;
            bfs(start, target);
        }
    }
}

