#include<bits/stdc++.h>
using namespace std;
int arr[100000000]={0};
int cieve(int n)
{
    int j,i;
    arr[1]=1;
    for(j=4;j<=n;j+=2){
        arr[j]=1;
    }
    for(i=3;i<=n;i+=2){
        if(arr[i]==0){
            for(j=i+i;j<=n;j+=i){
                arr[j]=1;
            }
        }
    }
    return arr[n];
}
int main()
{
    int m,p;
    cieve(1000001);
    while(cin>>m){
        p=0;
        for(int i=2; i<m; i++){
           if(arr[i]==0 && arr[m-i]==0){
                cout<<m<<":"<<endl;
                cout<<i<<"+"<<m-i<<endl;
                p=1;
                break;
           }
        }
        if(p==0){
            cout<<m<<":"<<endl;
            cout<<"NO WAY!"<<endl;
        }

    }
    return 0;
}
