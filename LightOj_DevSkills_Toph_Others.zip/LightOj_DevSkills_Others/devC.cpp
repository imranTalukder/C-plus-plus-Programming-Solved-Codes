#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    int t,n;
    ull m[1005],sum,mul;
    cin>>t;
    for(int i=1; i<=t; i++){
        cin>>n;
        sum=0;
        mul=1;
        for(int j=0; j<n; j++){
            cin>>m[j];
            sum=sum+m[j];

            mul=mul*m[j];
            if(mul>1006000007){
                mul=mul%1006000007;
            }
            if(mul==0){
                mul=1;
            }

        }
        sum=sum+mul;
        for(int j=0; j<n; j++){
            sum=sum+mul/m[j];

        }
        if(sum>1006000007){
                sum=sum%1006000007;
        }
        cout<<"Case "<<i<<": "<<sum<<endl;
    }



    return 0;
}

