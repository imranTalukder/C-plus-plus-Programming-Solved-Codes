#include<stdio.h>
int main(){

    int t,i;
    float x;
    scanf("%d",&t);
    for(i=1; i<=t; i++){
        scanf("%f",&x);
        x=x+x/3;
        printf("%f\n",x);
    }
    return 0;
}
