#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,b,value,a[100010],temp,cnt=0,ch[100010]={0},w;
    cin>>n>>b;
    for(int i=0; i<n; i++){
        cin>>value;
        a[i]=value;
    }
    for(int i=0; i<n; i++){
        if(a[i]>=b){
            break;
        }
        for(int j=0; j<n; j++){
            if(a[j]>=b){
                j++;
            }
            w=a[i]+a[j];
            if(w==b && i!=j){

                if(ch[i]==5 && ch[j] !=5){
                    cnt++;
                }
                else if( ch[j]==5 && ch[i] !=5){
                    cnt++;
                }
                else if(ch[j]!=5 && ch[i] !=5){
                    cnt=cnt+2;
                }
                ch[i]=5;
                ch[j]=5;
            }
        }
    }
    cout<<cnt<<endl;
    return 0;
}
