#include<bits/stdc++.h>
using namespace std;
int main()
{

    int t,n,k,cnt=0,v=5;
    cin>>t;
    for(int i=0; i<t; i++){
        cin>>n>>k;
        cnt=0;
        v=5;
        for(int j=3; j<=n; j++){
            cnt++;
            j=j+v;
            v=v+2;
            j--;
        }
        if(cnt==k){
            cout<<"I am married now"<<endl;
        }
        else{
            cout<<"Baba amar ki biye hobe na"<<endl;
        }
    }
    return 0;
}
