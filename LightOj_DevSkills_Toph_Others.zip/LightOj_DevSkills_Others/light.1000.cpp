#include<bits/stdc++.h>
using namespace std;
int main()
{
    char m[300];
    int maxx=0,cnt=0,len,n;
    cin>>n;
    getchar();
    cin.getline(m,250);
    for(int i=0; i<n; i++){
        if(m[i]>=65 && m[i]<=90){
            cnt++;
        }
        if(m[i]==' '){
            cnt=0;
        }
        maxx=max(cnt,maxx);
    }
    cout<<maxx<<endl;

    return 0;
}
