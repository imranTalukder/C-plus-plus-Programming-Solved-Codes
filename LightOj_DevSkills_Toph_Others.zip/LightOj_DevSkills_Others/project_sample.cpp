#include<bits/stdc++.h>
using namespace std;
int G[20][20];
int record1[20];
int dijsktra(int n,int startnode,int endnode)
{
    int cost[20][20],distance[20];
    int visited[20],cnt,mindistance,nextnode,i,j,k,s=1;
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            if(G[i][j]==0){
                cost[i][j]=9999;
            }
            else{
                cost[i][j]=G[i][j];
            }
        }
    }
    for(i=0; i<n; i++){
        distance[i]=cost[startnode][i];
        visited[i]=0;
    }
    distance[startnode]=0;
    visited[startnode]=1;
    cnt=1;
    record1[0]=startnode;
    while(cnt<n-1){
        mindistance=INFINITY;
        for(i=0; i<n; i++){
            if(distance[i]<mindistance && !visited[i]){
                mindistance=distance[i];
                nextnode=i;
            }
        }
        visited[nextnode]=1;
        record1[s]=nextnode;
        s++;
        if(nextnode==endnode){
            break;
        }
        for(k=0; k<n; k++){
            if(!visited[k]){
                if(mindistance+cost[nextnode][k]<distance[k])
                {
                    distance[k]=mindistance+cost[nextnode][k];
                }
            }
        }

        cnt++;
    }

    cout<<startnode<<" to "<<endnode<<" = "<<distance[endnode]<<endl;
    for(int a=0; a<s; a++){
        cout<<record1[a]<<" ";
    }
    return 0;
}


int main()
{
    int i,n,u,a,b,c,v;
    cout<<"No of edges"<<endl;
    cin>>n;
    cout<<"Enter the edges:"<<endl;
    for(i=0; i<n; i++){
        cin>>a>>b>>c;
        G[a][b]=c;
        G[b][a]=c;
    }
    cout<<"The starting node:"<<endl;
    cin>>u;
    cout<<"The endnode:"<<endl;
    cin>>v;
    dijsktra(n,u,v);
    return 0;
}

