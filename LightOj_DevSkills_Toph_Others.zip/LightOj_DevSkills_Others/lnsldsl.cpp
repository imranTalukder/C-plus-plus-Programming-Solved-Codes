
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,length,num,sum,c;
    scanf("%d",&t);
    while(t--){
            c=0;
        scanf("%d %d",&length,&num);
        int a[num];
        for(int j=0;j<num;j++){
            scanf("%d",&a[j]);
        }
        for(int i=0;i<num;i++){
            sum=a[i];
            for(int k=0;k<num;k++){
                if(k!=i)
                    {
                       sum=sum+a[k];
                if(sum==length){
                    printf("YES\n");
                    c++;
                }
                if(sum>length)
                    break;
                    }

            }
        }

        if(length==0){
            cout<<"YES"<<endl;
        }
        if(c==0){
            cout<<"NO"<<endl;
        }
    }
    return 0;
}
