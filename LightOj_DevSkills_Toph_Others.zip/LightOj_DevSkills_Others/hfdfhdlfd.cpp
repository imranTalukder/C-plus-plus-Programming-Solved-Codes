#include<stdio.h>
#include<math.h>
#define pi acos(-1)
int main()
{
	int i,T,L;
    double A1,A2,s,a;
	scanf("%d", &T);
	for(i=1;i<=T;i++){
		scanf("%d",&L);
		a=6.00*L/10.00;
		s=a*2.00/6.00;
	A1=pi*s*s;
		A2=a*L - A1;
		printf("%.2lf %.2lf\n",A1,A2);
	}
	return 0;
}

