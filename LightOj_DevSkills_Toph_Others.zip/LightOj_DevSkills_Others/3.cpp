#include<iostream>
using namespace std;
int main()
{
    int a[100],n,key,j;
    cout<<"Enter the number of people: "<<endl;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    for(int i=0; i<=n; i++){
        j=i-1;
        key=a[i];
        while(j>=0 && key<a[j]){
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=key;
    }
    for(int k=0; k<n; k++){
        cout<<a[k]<<" ";
    }
    return 0;
}
