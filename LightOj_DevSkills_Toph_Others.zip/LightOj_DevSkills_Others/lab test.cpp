#include<bits/stdc++.h>
using namespace std;
vector<long long>M[100000];
int bfs(long long source,long long endd)
{
    long long i;
    queue<long long>Q;
    long visit[100000]={0};
    long long dis[100000]={0};
    Q.push(source);
    visit[source]=1;
    dis[source]=0;
    while(! Q.empty()){
        long long u=Q.front();
        Q.pop();
        for(i=0; i<M[u].size(); i++){
            long long v=M[u][i];
            if(!visit[v]){
                Q.push(v);
                visit[v]=1;
                dis[v]=dis[u]+1;
                if(v==endd){
                    cout<<"The shortest path is: "<<dis[endd]<<endl;
                    break;
                }
            }
        }
    }


}
int main()
{
        long long total[100000]={0},number,x,y,i,source,endd;
        cin>>number;
        memset(M,NULL,sizeof(M));
        for(i=0; i<number; i++){
            cin>>x>>y;
            M[x].push_back(y);
            M[y].push_back(x);

        }
        cout<<"enter the source and end"<<endl;
        cin>>source>>endd;
         bfs(source,endd);
    return 0;
}
