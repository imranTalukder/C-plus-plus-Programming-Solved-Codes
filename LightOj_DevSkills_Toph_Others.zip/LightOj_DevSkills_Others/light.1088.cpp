#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long t,n,a[100015],q,ak,bk,cnt,mid,x,y,xy,pos1,pos2;
    scanf("%lld",&t);
    for(int i=1; i<=t; i++){
        scanf("%lld%lld",&n,&q);
        for(int j=1; j<=n; j++){
            scanf("%lld",&a[j]);
        }
        printf("Case %lld:\n",i);
        for(int j=1; j<=q; j++){
            scanf("%lld%lld",&ak,&bk);
            x=1;
            y=n;
            mid=0;
            while(x<=y){
                xy=x+y;
                mid=xy/2;
                if(a[mid]==ak){
                    x=mid;
                    break;
                }
                else if(a[mid]<ak){
                    x=mid+1;
                }
                else{
                    y=mid-1;
                }
            }
            pos1=x;
            x=1;
            y=n;
            mid=0;
            while(x<=y){
                xy=x+y;
                mid=xy/2;
                if(a[mid]<=bk){
                    x=mid+1;
                }

                else{
                    y=mid-1;
                }
            }
            pos2=x;
            printf("%lld\n",pos2-pos1);

        }
    }
    return 0;
}
