#include<bits/stdc++.h>
using namespace std;
int length(int num)
{
    int cnt=0;
    while(num>0){
        num=num/10;
        cnt++;
    }
    return cnt;
}
int main()
{
    int n,value,a[1005],temp;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>value;
        a[i]=value;
    }
    for(int i=0; i<n; i++)
    {
        for(int j=i+1; j<n; j++)
        {
            if(a[i]>a[j]){
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
            }
        }
    }
    for(int i=0; i<n; i++){
        int cnt=0;
        for(int j=0; j<4-length(a[i]); j++){
            cout<<"0";
            cnt++;
            if(cnt==4){
                cout<<endl;
            }
        }
        if(a[i]>0){
            cout<<a[i]<<endl;
        }
    }
    return 0;
}
