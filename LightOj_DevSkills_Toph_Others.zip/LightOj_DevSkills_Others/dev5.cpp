#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n,pos;
    long long val,maxx=0;
    cin>>t;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>val;
        if(val>maxx){
            maxx=val;
            pos=i;
        }
    }
}
