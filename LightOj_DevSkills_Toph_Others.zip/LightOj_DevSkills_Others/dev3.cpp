#include<bits/stdc++.h>
using namespace std;
int main()
{

    double a,s,res,k;
    int t;
    cin>>t;
    for(int i=1; i<=t; i++){
        cin>>a>>s;
        k=(s/a)+1.0;
        res=ceil(log10(k)/log10(2));
        cout<<"Case "<<i<<": "<<res<<endl;
    }
    return 0;
}
