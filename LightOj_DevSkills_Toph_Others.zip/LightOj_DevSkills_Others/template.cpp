#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);





    return 0;

    while(p==0){
        b=b-1;
        if(b>0){
            if(b%10==7 or b/10==7){
                res=(cnt-b)/x;
                cout<<res;
                return 0;
            }

        }
        sum=cnt-b;
        else{
           b=59;

        }

    }


}
