#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[200215]={0},k[200215]={0};
    int n,m,d=0;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>m;
        a[i]=m;
        if(k[m]==1){
            d--;
        }
        k[m]=1;
        d++;
    }
    for(int i=n-1; i>=0; i--){

        d--;
        if(d==0){
            if(k[a[i]]==1){
                cout<<a[i]<<endl;
                return 0;

            }
        }
        k[a[i]]=0;
    }
    return 0;
}
