#include<bits/stdc++.h>
using namespace std;
int a[600],n,m;
int first()
{
    for(int i=0; i<n-1; i++){
        a[i]=a[i+1];
    }
    a[n-1]=m;
}
int ffirst()
{
    for(int i=1; i<n-1; i++){
        a[i]=a[i+1];
    }
    a[n-1]=m;
}
int main()
{
    unsigned long long k,value=0,res;
    cin>>n>>k;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    while(value>k){
        if(a[0]>a[1]){
            value++;
            m=a[1];
            res=a[0];
            ffirst();
            if(value==k){
                cout<<res<<endl;
                return 0;
            }
        }
        else{
            value=0;
            m=a[0];
            first();

        }

    }
    return 0;
}
