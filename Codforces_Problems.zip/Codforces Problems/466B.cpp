#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long n,m[100010]={0},visit[100010]={0},cnt=0;
    cin>>n;
    for(int i=1; i<=n; i++){
        cin>>m[i];
    }
    for(int i=n; i>1; i--){
        for(int j=i-1; j>=1; j--){
            if(j>=i-m[i]){
                visit[j]=2;
            }
        }
    }
    for(int i=1; i<n; i++){
        for(int j=i+1; j<=n; j++){
            if(i>=j-m[j]){
                visit[i]=2;
            }
        }
    }
    for(int i=1; i<=n; i++){
        if(visit[i] !=2){
            cnt++;
        }
    }
    cout<<cnt<<endl;
    return 0;
}
