#include<bits/stdc++.h>
using namespace std;
int main()
{
    string m;
    int n,x=0,y=0,cnt1,cnt2,cnt;
    int d[2000]={0};
    cin>>n;
    cin>>m;
    for(int i=0; i<n; i++){

        if(m[i]=='U'){

            d[1]++;
        }
        else if(m[i]=='D'){

            d[2]++;
        }
        else if(m[i]=='L'){
           d[3]++;
        }
        else if(m[i]=='R'){
            d[4]++;
        }
        cnt1=min(d[1],d[2]);
        cnt2=min(d[3],d[4]);
        cnt=cnt1*2+cnt2*2;
    }
    cout<<cnt<<endl;
    return 0;
}
