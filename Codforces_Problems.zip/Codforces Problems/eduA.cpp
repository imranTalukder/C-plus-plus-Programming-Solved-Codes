#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,m[2000],cnt=0;
    cin>>a;
    for(int i=0; i<a; i++){
        cin>>m[i];
    }
    if(a<3){
        cout<<cnt<<endl;
        return 0;
    }
    else{
        for(int i=1; i<a-1; i++){
           if((m[i]>m[i-1]) && (m[i]>m[i+1])){
                cnt++;
           }
           else if((m[i]<m[i-1]) && (m[i]<m[i+1])){
                cnt++;
           }
        }
    }
    cout<<cnt<<endl;
    return 0;
}
