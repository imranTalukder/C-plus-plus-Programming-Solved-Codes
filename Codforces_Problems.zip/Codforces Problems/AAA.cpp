#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,a[2000],sum=0,mid,cnt=0,val=0;
    for(int i=1; i<=6; i++){
        cin>>a[i];
        sum=sum+a[i];
    }
    mid=sum/2;
    for(int i=1; i<=3; i++){
        val=a[i]+a[i+1]+a[i+2];
        if(val==mid){
            cout<<"YES"<<endl;
            return 0;
        }
    }
    cout<<"NO"<<endl;
    return 0;
}
