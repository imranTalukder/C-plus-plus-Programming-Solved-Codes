#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n,arr[500];
    cin>>n;
    int x=2*n-1;
    for(int i=0;i<x;i++){
        cin>>arr[i];

    }
    sort(arr,arr+x);
    int flag=0,sum=0;
    for(int i=0;i<x;i++){
        if(arr[i]<0 && flag<n){
            arr[i]=arr[i]*(-1);
            //cout<<"N:"<<arr[i]<<endl;
            sum+=arr[i];
            flag++;
        }
        else
            sum+=arr[i];

    }
    cout<<sum<<endl;

    return 0;

}
