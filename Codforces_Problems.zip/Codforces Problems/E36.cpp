
#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int n,k,ai,sum=0,val,res,minn=1000000;
    cin>>n>>k;
    for(int i=0; i<n; i++){
        cin>>ai;
        val=k%ai;
        if(val==0){
            ai=k/ai;
            if(minn>ai){
                res=ai;
            }
        }
    }

    cout<<res;

    return 0;
}
