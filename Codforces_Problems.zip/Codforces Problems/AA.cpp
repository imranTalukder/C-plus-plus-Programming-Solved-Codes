#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,a,b,k,sum=0;
    cin>>n>>a>>b;
    for(int i=0; i<n; i++){
        cin>>k;
        if(k==1 && a>0){
            a--;
        }
        else if(k==1 && a==0 && b>0){
            b--;
            a++;
        }
        else if(k==1 && a==0 && b==0){
            sum++;
        }
        else if(k==2 && b>0){
            b--;
        }
        else if(k==2 && b==0){
            sum=sum+2;
        }

    }
     cout<<sum<<endl;
    return 0;
}
