#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int n,pos,k,r,res=0;
    cin>>n>>pos>>k>>r;

    if(k==1 && r ==n){
        cout<<res;
        return 0;
    }
    else if(k==1 && r<n){
        if(pos>=r){
            res=pos-r+1;
        }
        if(pos<r){
            res=r-pos+1;
        }
    }
    else if(k>1 && r==n){
        if(pos<k){
            res=k-pos+1;
        }
        if(pos>=k){
            res=pos-k+1;
        }
    }
    else if(k>1 && r<n){
        if(pos<k){
            res=k-pos+1+r-k+1;

        }
        else if(pos>r){
            res=pos-r+1+r-k+1;
        }
        else{
            int mn1,mn2;
            mn1=pos-k;
            mn2=r-pos;
            if(mn1>=mn2){
                res=pos-k+1+r-k+1;
            }
            else{
                res=r-pos+1+r-k+1;
            }
        }
    }

    cout<<res;

    return 0;
}

