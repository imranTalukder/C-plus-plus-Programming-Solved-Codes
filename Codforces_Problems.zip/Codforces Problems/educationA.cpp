#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,t,day,time=0,s,cnt=0;;
    cin>>n>>t;
    for(int i=0; i<n; i++){
        cin>>s;
        time+= 86400-s;
        if(time<t){
            cnt++;
        }
        if(time>=t){
            cnt++;
            cout<<cnt<<endl;
            return 0;
        }
    }
    return 0;
}
