#include<stdio.h>
int main()
{
	int n,i,k,s=0,a;
	while(scanf("%d", &n) !=EOF){
	for(i=1; i<=n; i++){
		scanf("%d", &k);
		if(k>=1 && k<=4){
		s=s+k;
		}
	}
	if(s%4==0){
		a=s/4;
		printf("%d\n", a);
	}
	else
	{
		a=s/4+1;
		printf("%d\n", a);
		}
		s=0;
	}

		return 0;
}
