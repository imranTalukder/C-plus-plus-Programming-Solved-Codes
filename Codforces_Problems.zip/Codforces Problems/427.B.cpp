#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long k2i,num,sum=0,i,len,var,cnt=0,j,pum[9]={0};
    char n[100005];
    cin>>k2i;
    cin>>n;
    len=strlen(n);
    for(i=0; i<len; i++){
        sum=sum+(n[i]-48);
        pum[n[i]-48]++;
    }
    if(sum>=k2i){
        cout<<"0"<<endl;
    }
    else{
        for(j=0; j<=9; j++){
            while(pum[j]>0 && sum<k2i){
                sum=sum+9-j;
                pum[j]--;
                cnt++;
            }
        }
        cout<<cnt<<endl;
    }
    return 0;
}
