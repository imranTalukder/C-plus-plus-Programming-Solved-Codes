#include<bits/stdc++.h>
using namespace std;
int main()
{
    int s,v1,v2,t1,t2,sum1,sum2;
    cin>>s>>v1>>v2>>t1>>t2;
    sum1=s*v1+2*t1;
    sum2=s*v2+2*t2;
    if(sum1<sum2){
        cout<<"First"<<endl;
    }
    else if(sum2<sum1){
        cout<<"Second"<<endl;
    }
    else{
        cout<<"Friendship"<<endl;
    }
    return 0;
}
