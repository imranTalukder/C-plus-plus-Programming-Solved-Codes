#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long n,x,sum,i,c;
    cin>>n>>x;
    sum=n-1;
    for(i=0; i<n; i++){
        cin>>c;
        sum+=c;
    }
    if(x==sum){
        cout<<"YES"<<endl;
    }
    else{
        cout<<"NO"<<endl;
    }
    return 0;
}

