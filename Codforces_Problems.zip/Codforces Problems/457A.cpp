#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int x,a,b,res=0,cnt=0,p=0,sum;
    cin>>x;
    cin>>a>>b;
    cnt=b;
    if(b%10==7){
        cout<<res;
    }
    else if(b>7){
        for(int i=1; i<7; i++){
            b=b-1;
            if(b%10==7){
                res=(cnt-b)/x;
                cout<<res;
            }
        }
    }
    else if(b<7){
        sum=b+4;
        res=sum/x;
        cout<<res;
    }


    return 0;
}

