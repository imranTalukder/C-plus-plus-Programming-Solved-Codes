#include<bits/stdc++.h>
using namespace std;
int main()
{
    char m[300];
    int maxx=0,cnt=0,n;
    cin>>n;
    for(int i=0;i<=n;i++){
        scanf("%c",&m[i]);
        if(isupper(m[i])){
            cnt++;
        }
        if(m[i]==' '){
            if(maxx<cnt)
                maxx=cnt;
            cnt=0;
        }
    }
    if(cnt>maxx)
        cout<<cnt<<endl;
    else
        cout<<maxx<<endl;

    return 0;
}
