#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int m,s[10000],k=0,value[10000],check[100010]={0},dd;
    cin>>m;
    for(int i=0; i<m; i++){
        cin>>s[i];
        check[s[i]]=1;
    }
    for(int i=0; i<m; i++){
        for(int j=2; j<=s[m-1]; j++){
            dd=s[i]*j;
            if(dd>s[m-1]){
                break;
            }
            else if(dd<=s[m-1] && check[dd]==1 && k<=4000){
                value[k]=s[i]*j;
                k++;
                check[dd]++;

            }
        }
    }
    if(k==0){
        cout<<"-1";
    }
    else{
        cout<<k<<endl;
        for(int j=0; j<k-1; j++){
            cout<<value[j]<<" ";
        }
        cout<<value[k-1];
    }
    return 0;
}

