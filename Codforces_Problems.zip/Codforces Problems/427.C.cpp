#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,i,k,p,j,q,c,xi,val,yi,si,s,d,sum=0,ti,x1i,y1i,x2i,y2i;
    int arr[105][105];
    for(int s=0; s<=101; s++){
        for(int d=0; d<=100; d++){
            arr[s][d]=-1;
        }
    }
    cin>>n>>q>>c;
    for(i=0; i<n; i++){
        cin>>xi>>yi>>si;
        arr[xi][yi]=si;
    }
    for(j=0; j<q; j++){
        sum=0;
        cin>>ti>>x1i>>y1i>>x2i>>y2i;
        for(k=x1i; k<=y2i; k++){
            for(p=x1i; p<=y2i; p++){
                val=arr[k][p];
                if(val >=0){
                    sum=sum+((ti+arr[k][p])%(c+1));

                }
            }
        }
        cout<<sum<<endl;
    }
    return 0;
}
