#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    unsigned long long n,res;
    int a[20],b[20],i=0,cnt=0,val;
    cin>>n>>res;
    while(n>0){
        val=n%10;
        n=n/10;
        a[i]=val;
        i++;
        cnt++;
    }
    i=0;
    int cnt2=0,temp;
    while(res>0){
        val=res%10;
        res=res/10;
        b[i]=val;
        i++;
        cnt2++;
    }
    sort(a,a+cnt);
    for(int i=0; i<cnt; i++){
        if(a[i]==0){
            a[i]=temp;
            temp=a[i+1];
            a[i+1]=temp;
        }
    }
    for(int f=0; f<cnt; f++){
        cout<<a[f];

    }


    return 0;
}

