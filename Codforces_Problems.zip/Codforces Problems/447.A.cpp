#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    int len,cnt=0;
    string s;
    cin>>s;
    len=s.length();

    for(int i=0; i<len; i++){
        if(s[i]=='Q'){
            for(int j=i+1; j<len; j++){
                if(s[j]=='A'){
                    for(int k=j+1; k<len; k++){
                        if(s[k]=='Q'){
                            cnt++;
                        }
                    }
                }
            }
        }

    }
    cout<<cnt;

    return 0;
}

