#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[10]={0};
    int n,s,p;
    cin>>n;
    for(int j=1; j<=n; j++){
        for(int i=0; i<6; i++){
            cin>>p;
            a[p]++;
        }
    }
    if(a[1]==0){
        cout<<"0"<<endl;
        return 0;
    }
    for(int i=1; i<10; i++){
        p=a[i];
        if(p<2){
            s=i*10+i-1;
            cout<<s<<endl;
            return 0;
        }
    }
    return 0;
}
