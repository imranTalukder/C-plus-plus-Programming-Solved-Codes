#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,g_n,a_n,p,k,t_n,report;
    map<char,int>gd;
    char good[26],all[10005],test[10005];
    cin>>good;
    g_n=strlen(good);
    for(int i=0; i<g_n; i++){
        gd[good[i]]=5;
    }
    cin>>all;
    a_n=strlen(all);
    for(int i=0; i<a_n; i++){
        if(all[i]=='*'){
            p=5;
        }
    }

    cin>>n;
    while(n--){
        cin>>test;
        report=0;
        t_n=strlen(test);
        if(a_n-t_n>1 || a_n-t_n<-1 ){
            cout<<"NO"<<endl;
        }
        else if(a_n !=t_n && p !=5){
            cout<<"NO"<<endl;
        }
        else if(a_n-t_n==1 && p==5){
            k=0;
            for(int i=0; i<t_n; i++){
                if(all[k]=='*'){
                    k++;
                }
                if(all[k] !=test[i]){
                    if(all[k]=='?' && gd[test[i]] !=5){
                            report=5;
                    }
                }
                k++;
            }
            if(report==5){
                cout<<"NO"<<endl;
            }
            else{
                cout<<"YES"<<endl;
            }
        }
        else if(a_n-t_n==-1 && p==5){

            cout<<"NO"<<endl;
        }
        else if(a_n==t_n){
            for(int i=0; i<a_n; i++){
                if(all[i] !=test[i]){
                    if(all[i]=='?' && gd[test[i]] !=5){
                        report=5;
                    }
                    if(all[i] !='?' && all[i] !='*'){
                        report=5;
                    }
                }
            }
            if(report==5){
                cout<<"NO"<<endl;
            }
            else{
                cout<<"YES"<<endl;
            }
        }
    }
    return 0;
}
