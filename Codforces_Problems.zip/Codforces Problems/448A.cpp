#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int n,sum=0;
    int a[1000];
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
        sum=sum+a[i];
    }

    sort(a,a+n);
    int p,q;

    int sum1=0, sum2=0,test,test2;
    for(int i=n-1; i>=0; i--){

        p=sum1;
        q=sum2;
        sum1=sum1+a[i];
        sum2=sum2+a[i];
        test=abs(sum1-q);
        test2=abs(sum2-p);


        if(test>test2){
            sum1=p;

        }
        else{
            sum2=q;

        }


    }
    sum=abs(sum2-sum1);
    cout<<sum<<endl;


    return 0;
}

