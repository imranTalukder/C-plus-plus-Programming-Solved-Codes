#include<bits/stdc++.h>
using namespace std;
int main()
{
    int s,p=0,cnt=1;
    string m;
    cin>>m;
    s=m.length();
    if(s<9){
        cout<<"no"<<endl;
        return 0;
    }
    for(int i=0; i<s; i++){
        if(m[i]=='1'){
            p=1;
        }
        if(p==1 && m[i]=='0'){
            cnt++;
            if(cnt>=7){
                cout<<"yes"<<endl;
                return 0;
            }
        }
    }
    cout<<"no"<<endl;
    return 0;
}
