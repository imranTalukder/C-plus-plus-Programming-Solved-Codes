#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,s,d,mm=0,h;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>s>>d;
        for(int j=1; j<=1000000; j++){
            h=s+(j-1)*d;
            if(h>mm){
                mm=h;

                break;
            }
        }

    }
    cout<<mm<<endl;
    return 0;
}
