#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,a,b,sum1,sum2,k,sum=0;
    cin>>n>>a>>b;
    sum1=a;
    sum2=b*2;
    for(int i=1; i<=n; i++){
        cin>>k;
        sum=sum+k;
    }
    if(sum>>sum1+sum2){
        cout<<sum-sum1-sum2<<endl;
    }
    else{
        cout<<"0"<<endl;
    }
    return 0;
}
