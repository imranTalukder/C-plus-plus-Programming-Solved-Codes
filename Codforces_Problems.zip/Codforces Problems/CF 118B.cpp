#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,p=0,m,k,j;
    cin>>n;
    m=n;
    n=n-1;
    for(int l=0; l<=n; l++){
        cout<<"  ";
    }
    cout<<p<<endl;
    for(int i=1; i<=n+1; i++){
        k=n-i+1;
        while(k>0){
            cout<<"  ";
            k--;
        }

        for(j=0; j<i; j++){

            cout<<j<<" ";
        }
        while(j>=0){
            cout<<j;
            if (j !=0){
                cout<<" ";
            }
            j--;
        }
        cout<<endl;

    }
    for(int i=n; i>=1; i--){
        k=n-i+1;
        while(k>0 && k<=n){
            cout<<"  ";
            k--;
        }

        for(j=0; j<i; j++){

            cout<<j<<" ";

        }
        while(j>=0){
            cout<<j;
            if(j>0){
                cout<<" ";
            }
            j--;
        }
        cout<<endl;

    }
    for(int l=0; l<=n; l++){
        cout<<"  ";
    }
    cout<<p<<endl;
    return 0;
}
