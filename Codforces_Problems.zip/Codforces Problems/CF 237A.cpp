#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,h,m,sum=1,p=-2,q=-5,c=1;
    cin>>n;
    while(n){
        cin>>h>>m;
        if(p==h && q==m){
            sum++;
            if(c<sum){
                c=sum;
            }
        }
        else{
            sum=1;
        }
        p=h;
        q=m;
        n--;
    }
    cout<<c<<endl;
    return 0;
}
