#include <bits/stdc++.h>
#define ull unsigned long long
using namespace std;

ull pal[100010];
int s=0;
int createPalindrome(ull input, bool isOdd)
{
    ull n = input;
    ull palin = input;

    if (isOdd)
        n /= 10;

    while (n > 0)
    {
        palin = palin * 10 + (n % 10);
        n /= 10;
    }
    return palin;
}
void generatePaldindromes(ull n)
{
    ull number;

    for (int j = 0; j < 2; j++)
    {
        ull i = 1;

        while ((number = createPalindrome(i, j % 2)) < n)
        {
            ull val=number,cnt=1;
            while(val>=10){
                cnt++;
                val=val/10;
            }
            if(cnt%2==0){
                i++;
                pal[s]=number;
                s++;
            }
            if(s>10000){
                break;
            }

        }

    }
}
int main()
{
    ull n = 10000000000,k,p;
    ull sum=0;
    generatePaldindromes(n);
    cin>>k>>p;
    for(int q=0; q<k; q++){
        sum=sum+pal[q];

    }
    sum=sum%p;

    cout<<sum<<endl;
    return 0;
}
