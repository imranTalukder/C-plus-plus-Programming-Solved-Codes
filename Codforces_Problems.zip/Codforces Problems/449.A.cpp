#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);

    int n,m;
    string s;
    int l,r;
    char c1;
    char c2;
    cin>>n>>m;
    cin>>s;
    for(int i=0; i<m; i++){
        cin>>l>>r>>c1>>c2;
        for(int j=l-1; j<=r-1; j++){
            if(s[j]==c1){
                s[j]=c2;
            }
        }
    }
    cout<<s<<endl;




    return 0;
}

