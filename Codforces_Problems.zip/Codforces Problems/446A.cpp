#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long long n,rem[100010],cap[100010],i,sum=0,maxx1=0,maxx2=0,dif,pos1=0,pos2=0,maxx=0;

    cin>>n;
    for(i=0; i<n; i++){
        cin>>rem[i];
        sum=sum+rem[i];
        if(rem[i]>=maxx){
            maxx2=maxx1;
            pos2=pos1;
            maxx1=rem[i];
            pos2=i;

        }
    }
    for(i=0; i<n; i++){
        cin>>cap[i];

    }

    sum=sum-rem[pos1]-rem[pos2];
    dif=(cap[pos1]-rem[pos1])+(cap[pos2]-rem[pos2]);
    if(sum>dif){
        cout<<"NO"<<endl;
    }
    else{
        cout<<"YES"<<endl;
    }

    return 0;
}
/*


ll A[100005];

int main()
{
    ll N,M=0,K;

    cin>>N;
    for(int i=1;i<=N;i++)
    {
        cin>>K;
        M+=K;
    }
    for(int i=0;i<N;i++) cin>>A[i];
    sort(A,A+N);
    if(A[N-1]+A[N-2] >= M) cout<<"YES";
    else cout<<"NO";
    return 0;
}
*/
