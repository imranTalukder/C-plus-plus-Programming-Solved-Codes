#include<bits/stdc++.h>

#define INFINITY 9999
#define MAX 10
using namespace std;
int dijsktra(int G[MAX][MAX],int n,int startnode)
{
    int cost[MAX][MAX],distance[MAX],pred[MAX];
    int visited[MAX],cnt,mindistance,nextnode,i,j,k;
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            if(G[i][j]==0){
                cost[i][j]=INFINITY;
            }
            else{
                cost[i][j]=G[i][j];
            }
        }
    }
    for(i=0; i<n; i++){
        distance[i]=cost[startnode][i];
        pred[i]=startnode;
        visited[i]=0;
    }
    distance[startnode]=0;
    visited[startnode]=1;
    cnt=1;
    while(cnt<n-1){
        mindistance=INFINITY;
        for(i=0; i<n; i++){
            if(distance[i]<mindistance && !visited[i]){
                mindistance=distance[i];
                nextnode=i;
            }
        }
        visited[nextnode]=1;
        for(k=0; k<n; k++){
            if(!visited[k]){
                if(mindistance+cost[nextnode][k]<distance[k])
                {
                    distance[k]=mindistance+cost[nextnode][k];
                    pred[k]=nextnode;
                }
            }
        }

        cnt++;
    }

    for(i=0; i<n; i++){
        cout<<startnode<<" to "<<i<<" = "<<distance[i]<<endl;
    }
    return 0;
}


int main()
{
    int G[MAX][MAX],i,j,n,u;
    cout<<"No of edges"<<endl;
    cin>>n;
    cout<<"Enter the matrix"<<endl;
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            cin>>G[i][j];
        }
    }
    cout<<"The starting node"<<endl;
    cin>>u;
    dijsktra(G,n,u);
    return 0;
}
