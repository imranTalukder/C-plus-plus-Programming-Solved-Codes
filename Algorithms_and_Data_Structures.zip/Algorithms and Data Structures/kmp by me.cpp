#include<bits/stdc++.h>
using namespace std;
int pre[100];
int prefix(string p)
{
    int i,j=0,m;
    m=p.length();
    pre[0]=0;
    for(i=1; i<m; i++){
        while(j<i && p[i] !=p[j] && j!=0)
        {
            j=pre[j-1];
        }
        if(p[i]==p[j])
        {
            j++;
        }
        pre[i]=j;
    }

}
bool kmp(string t,string p)
{
    int a,b,g,h=0,q=0;
    a=t.length();
    b=p.length();
    prefix(p);
    for(g=0; g<a; g++){
        while(h<g && t[g] !=p[h] && h>0)
        {
            h=pre[h-1];

        }
        if(t[g]==p[h]){
            h++;
            if(h==b){
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    int x;
    char t[500],p[100];

    gets(t);
    gets(p);

    x=kmp(t,p);
    if(x){
        cout<<"Found"<<endl;
    }
    else{
        cout<<"Not found"<<endl;
    }
    return 0;
}

