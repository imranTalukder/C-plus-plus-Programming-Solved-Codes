#include<bits/stdc++.h>
using namespace std;
int main()
{
    int x;
    queue<int>imran;
    imran.push(5);
    imran.push(10);
    imran.push(15);
    for(int i=0; i<3; i++){
        x=imran.front();
        cout<<x<<" ";
        imran.pop();
    }
    return 0;
}
