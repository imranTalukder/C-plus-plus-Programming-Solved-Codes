#include<bits/stdc++.h>
using namespace std;
int dis[100]={0};
int bfs(vector<int>G[100],int start)
{
    int visited[100]={0};
    queue<int>Q;
    Q.push(start);
    visited[start]=1;
    dis[start]=0;
    while(!Q.empty()){
        int u=Q.front();
        Q.pop();
        for(int i=0; i<G[u].size(); i++){
            int v=G[u][i];
            if(visited[v]==0){
                 Q.push(v);
                 visited[v]=1;
                 dis[v]=dis[u]+1;
            }
        }
    }
}
int main()
{
    int node, edge,x,y,start,endd,t;
    cout<<"Enter the test case"<<endl;
    cin>>t;
    while(t--){
        vector<int>G[100];
        cout<<"Enter the number of edge"<<endl;
        cin>>edge;
        cout<<"Enter the value"<<endl;
        for(int i=0; i<edge; i++){
            cin>>x>>y;
            G[x].push_back(y);
            G[y].push_back(x);
        }
        cout<<"Source node"<<endl;
        cin>>start;
        bfs(G,start);
        cout<<"Enter the destination node"<<endl;
        cin>>endd;
        cout<<"The length is: "<<dis[endd]<<endl;

    }
    return 0;
}
