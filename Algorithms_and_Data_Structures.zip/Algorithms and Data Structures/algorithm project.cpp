#include<bits/stdc++.h>


using namespace std;
int G[10][10],F[10][10];
int money[10];
int valuem;
int valuet;
int timet[10];
int dijsktra(int n,int startnode,int endnode)
{
    int cost[10][10],distance[10],pred[10],pp=1;
    int visited[10],cnt,mindistance,nextnode,i,j,k,path[10][10]={0};
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            if(G[i][j]==0){
                cost[i][j]=99999;
            }
            else{
                cost[i][j]=G[i][j];
            }
        }
    }
    for(i=0; i<n; i++){
        distance[i]=cost[startnode][i];
        pred[i]=startnode;
        visited[i]=0;
    }
    distance[startnode]=0;
    visited[startnode]=1;
    cnt=1;
    money[pp]=startnode;
    pp++;
    while(cnt<n-1){
        mindistance=99999;
        for(i=0; i<n; i++){
            if(distance[i]<mindistance && !visited[i]){
                mindistance=distance[i];
                nextnode=i;

            }
        }
        if(nextnode !=endnode){
            money[pp]=nextnode;
            pp++;
            visited[nextnode]=1;
            for(k=0; k<n; k++){
                if(!visited[k]){
                    if(mindistance+cost[nextnode][k]<distance[k])
                    {
                        distance[k]=mindistance+cost[nextnode][k];
                        pred[k]=nextnode;
                    }
                }
            }

        }
        cnt++;
    }
    money[pp]=endnode;
    valuem=distance[endnode];
    for(int v=1; v<=8; v++){
        if(money[v]>0){
            cout<<money[v]<<"-->";
        }
        else{
            break;
        }
    }
    return 0;
}

int hdijsktra(int n,int startnode,int endnode)
{
    int cost[10][10],distance[10],pred[10],pp=1;
    int visited[10],cnt,mindistance,nextnode,i,j,k,path[10][10]={0};
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            if(F[i][j]==0){
                cost[i][j]=99999;
            }
            else{
                cost[i][j]=F[i][j];
            }
        }
    }
    for(i=0; i<n; i++){
        distance[i]=cost[startnode][i];
        pred[i]=startnode;
        visited[i]=0;
    }
    distance[startnode]=0;
    visited[startnode]=1;
    cnt=1;
    timet[pp]=startnode;
    pp++;
    while(cnt<n-1){
        mindistance=99999;
        for(i=0; i<n; i++){
            if(distance[i]<mindistance && !visited[i]){
                mindistance=distance[i];
                nextnode=i;

            }
        }
        if(nextnode !=endnode){
            timet[pp]=nextnode;
            pp++;
            visited[nextnode]=1;
            for(k=0; k<n; k++){
                if(!visited[k]){
                    if(mindistance+cost[nextnode][k]<distance[k])
                    {
                        distance[k]=mindistance+cost[nextnode][k];
                        pred[k]=nextnode;
                    }
                }
            }

        }
        cnt++;
    }
    timet[pp]=endnode;
    valuet=distance[endnode];
    /*
    for(int v=1; v<=8; v++){
        if(timet[v]>0){
            cout<<timet[v]<<"-->";
        }
        else{
            break;
        }
    }
    */
    return 0;
}

int main()
{
    int i,j,n,u,a,b,c,r,q,h;
    int time1=0,mon1=0;
    cout<<"No of Cities in Your Area: ";
    cin>>n;
    cout<<"No. of Roads in Your Area: ";
    cin>>q;
    cout<<"Enter place1,place2 code and Required money, Time: "<<endl;
    for(i=0; i<q; i++){
        cin>>a>>b>>c>>h;
        G[a][b]=c;
        G[b][a]=c;
        F[a][b]=h;
        F[b][a]=h;
    }
    cout<<"Your Current Area Code"<<endl;
    cin>>u;
    cout<<"Your Destination Area Code"<<endl;
    cin>>r;
    dijsktra(n,u,r);
    cout<<endl;
    hdijsktra(n,u,r);
    int kk;
    kk=u;
    for(int v=1; v<=8; v++){
        if(money[v]>0 && money[v+1]>0){
            time1=time1+F[money[v]][money[v+1]];
        }
        else{
            break;
        }
    }
    for(int v=1; v<=8; v++){
        if(timet[v]>0 && timet[v+1]>0){
            mon1=mon1+G[timet[v]][timet[v+1]];
        }
        else{
            break;
        }
    }

    kk=(valuet*valuem)/(time1*mon1);
    cout<<endl;
    cout<<"------------------------------------------------------"<<endl;
    cout<<"After Calculating Based On Money & Time, your Best Way IS:"<<endl;
    cout<<endl;
    if(kk>=1){
        for(int v=1; v<=8; v++){
            if(timet[v]>0){
                cout<<timet[v]<<"-->";
            }
            else{
                break;
            }
        }
    }
    else{
        for(int v=1; v<=8; v++){
            if(money[v]>0){
                cout<<money[v]<<"-->";
            }
            else{
                break;
            }
        }
    }

    return 0;
}
