#include<bits/stdc++.h>
using namespace std;
int prefix[100];
void pre(string p)
{
    int n,j=0;
    n=p.size();
    prefix[0]=0;
    for(int i=1; i<n; i++){
        while(j>0 && p[j] !=p[i])
        {
            j=prefix[j-1];
        }
        if(p[j]==p[i]){
            j++;
        }
        prefix[j]=j;
    }
}
int kmp(string t, string p)
{
    int m,j=0,d;
    pre(p);
    d=p.length();
    m=t.length();
    for(int i=0; i<m; i++){
        while(j>0 && t[i] !=p[j]){
            j=prefix[j-1];
        }
        if(t[j]==p[j]){
            j++;
        }
        if(j==d){
            cout<<"Found"<<endl;
        }
        prefix[j]=j;
    }
    cout<<"Not Found"<<endl;
}
int main()
{
    string t="imrantalukder",p="ra";
    kmp(t,p);
    return 0;
}
