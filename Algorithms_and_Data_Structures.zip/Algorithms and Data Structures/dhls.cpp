#include<bits/stdc++.h>
using namespace std;
int main()
{
    int stk[11],top=0,p=0;
    for(int i=0; i<10; i++){
        stk[i]=p;
        p++;
    }
    cout<<p<<"  "<<stk[p]<<endl;
    //cout<<stk[--p]<<endl;
    cout<<stk[p--]<<endl;
    cout<<stk[p]<<endl;
    return 0;
}
