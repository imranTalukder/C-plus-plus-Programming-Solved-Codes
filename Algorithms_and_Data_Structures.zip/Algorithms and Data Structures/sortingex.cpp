#include<bits/stdc++.h>
using namespace std;
int a[]={1,3,2,5,4 };


   void insertion(int a[], int n ) {
   int i,j,key;
   for(i=1; i<n; i++){
    j=i-1;
   key=a[i];
   while(j>=0 && j>key)
   {
       a[j]=a[j+1];
       j--;
   }
   a[j+1]=key;

}
   }
   int main()
   {
       int n= sizeof(a)/sizeof(a[0]);
       insertion( a,  n);
       for(int i=0; i<n; i++)
       {
           cout<<a[i]<<"\t";
       }
       return 0;
   }
