#include<bits/stdc++.h>
using namespace std;
vector<int>G[100];
int bfs(int s, int last)
{
    queue<int>Q;
    int dis[100]={0};
    int visit[100]={0};
    Q.push(s);
    visit[s]=1;
    dis[s]=0;
    int v;
    cout<<"enter the node where you want to go.."<<endl;
    while(!Q.empty()){
        int u=Q.front();
        Q.pop();
        for(int i=0; i<G[u].size(); i++){
            v=G[u][i];
            if(!visit[v]){
                Q.push(v);
                visit[v]=1;
                dis[v]=dis[u]+1;
            }
            if(v==last){
                cout<<"here is your result: "<<dis[last]<<endl;
                return 0;
            }
        }
    }
}

int main()
{
    int e,t,res,ab,kb,bb;
    char a[7];
    cout<<"enter the edge number"<<endl;
    cin>>e;
    cout<<"enter the edge ...."<<endl;
    for(int i=0; i<e; i++){
        int x,y;
        cin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);

    }
    int s;
    s=0;
    for(int f=0; f<3; f++){
        cin>>a>>t;
        res=bfs(s,t);
        if(a=="Abul"){
            ab=res;
        }
        else if(a=="Kabul"){
            kb=res;
        }
        else if(a=="Babul"){
            bb=res;
        }
    }
    if(kb>bb && bb>=ab){
        cout<<"Marry Kabul"<<endl;
    }
    else if(ab>bb && bb>=kb){
        cout<<"Marry Aabul"<<endl;
    }
    else if(bb>kb && kb>=ab){
        cout<<"Marry Babul"<<endl;
    }
    return 0;
}
