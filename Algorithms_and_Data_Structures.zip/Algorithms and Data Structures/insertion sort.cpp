#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[]={4,1,3,2,5},key;
    for(int j=1; j<sizeof(a)/4; j++){
        int i=j-1;
        key=a[j];
        while(i>=0 && key<a[i]){
            a[i+1]=a[i];
            i--;
        }
        a[i+1]=key;
    }
    for(int i=0; i<sizeof(a)/4; i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
