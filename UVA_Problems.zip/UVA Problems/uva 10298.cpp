#include<bits/stdc++.h>
using namespace std;
int n=1000005;
int pre[1000005];
int prefix(string p)
{
    int i,j=0,m;
    m=p.length();
    pre[0]=0;
    for(i=1; i<m; i++){
        while(j<i && p[i] !=p[j] && j!=0)
        {
            j=pre[j-1];
        }
        if(p[i]==p[j])
        {
            j++;
        }
        pre[i]=j;
    }
    cout<<m/(m-pre[m-1])<<endl;
}
int main()
{
    char d[n];
    while (~scanf("%s", d) && strcmp(d, ".") != 0) {
	prefix(d);
    }
    return 0;
}
