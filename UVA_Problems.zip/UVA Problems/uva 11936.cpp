#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    while(n--){
        int a,b,c,sum,p;
        cin>>a>>b>>c;
        sum=a+b+c;
        b=max(a,b);
        p=max(b,c);
        if(sum-p>p){
            cout<<"OK"<<endl;
        }
        else{
            cout<<"Wrong!!"<<endl;
        }
    }
    return 0;
}
