#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,p=1;
    while(cin>>n){
        int m,a[100];
        for(int i=0; i<n; i++){
            cin>>a[i];
        }
        long long mx=0;
        for(int i=0; i<n; i++){
            for(int j=i; j<n; j++){
                long long sum=1;
                for(int k=i; k<=j; k++){
                    sum=sum*a[k];
                }
               mx=max(mx,sum);
            }
        }

    cout<<"Case #"<<p<<": The maximum product is "<<mx<<"."<<endl<<endl;
    p++;
    }
    return 0;
}
