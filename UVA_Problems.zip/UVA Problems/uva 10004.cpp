#include<bits/stdc++.h>
using namespace std;
vector<int>G[300];
int bfs(int n)
{
    int cnt=0;
    int visit[100005]={0};
    queue<int>Q;
    Q.push(0);
    visit[0]=0;
    int dis[100005]={0};
    dis[0]=1;
    while(! Q.empty()){
        int u=Q.front();
        Q.pop();
        for(int i=0; i<G[u].size(); i++){
            int v=G[u][i];
            if(! dis[v]){
                if(visit[u]==0){
                    visit[v]=1;
                }
                Q.push(v);
                dis[v]=1;
            }
        }
    }
    for(int i=0; i<n; i++){
        for(int j=0; j<G[i].size(); j++){
            if(visit[i]==visit[G[i][j]]){
                cnt=1;
            }
        }
    }

    if(cnt){
        cout<<"NOT BICOLORABLE."<<endl;
    }
    else{
        cout<<"BICOLORABLE."<<endl;
    }

}
int main()
{
    int p,l,x,y;
    while(cin>>p){
        if(p==0){
            return 0;
        }
        cin>>l;
        for(int i=0; i<l; i++){
            cin>>x>>y;
            G[x].push_back(y);
            G[y].push_back(x);
        }
        bfs(p);
        for(int i=0; i<300; i++){
            G[i].clear();
        }
    }
    return 0;
}
