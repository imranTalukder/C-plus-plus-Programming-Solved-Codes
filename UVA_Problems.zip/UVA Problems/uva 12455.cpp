#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,length,num;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&length,&num);
        int a[num];
        int sin=0;
        if(length==0){
            sin=1;
        }
        for(int j=0;j<num;j++){
            scanf("%d",&a[j]);
        }
        for(int i=0; i<num; i++){
            int sum=a[i];
            if(sum==length){
                sin=1;
                break;
            }
            for(int j=0; j<num; j++){
                if(i!=j){
                    sum=sum+a[j];
                }
                if(sum==length){
                    sin=1;
                    break;
                }
            }
        }
        if(sin==1){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}
