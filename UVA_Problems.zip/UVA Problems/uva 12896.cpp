#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,l;
    cin>>t;
    while(t--){
        int a[105],b[105];
        cin>>l;
        for(int i=0; i<l; i++){
            cin>>a[i];
        }
        for(int i=0; i<l; i++){
            cin>>b[i];
        }
        for(int i=0; i<l; i++){
            if(a[i]==1){
                if(b[i]==1){
                    cout<<".";
                }
                if(b[i]==2){
                    cout<<",";
                }
                if(b[i]==3){
                    cout<<"?";
                }
                if(b[i]==4){
                    char p='"';
                    cout<<p;
                }
            }
            else if(a[i]==2){
                if(b[i]==1){
                    cout<<"a";
                }
                if(b[i]==2){
                    cout<<"b";
                }
                if(b[i]==3){
                    cout<<"c";
                }
            }
            else if(a[i]==3){
                if(b[i]==1){
                    cout<<"d";
                }
                if(b[i]==2){
                    cout<<"e";
                }
                if(b[i]==3){
                    cout<<"f";
                }
            }
            else if(a[i]==4){
                if(b[i]==1){
                    cout<<"g";
                }
                if(b[i]==2){
                    cout<<"h";
                }
                if(b[i]==3){
                    cout<<"i";
                }
            }
            else if(a[i]==5){
                if(b[i]==1){
                    cout<<"j";
                }
                if(b[i]==2){
                    cout<<"k";
                }
                if(b[i]==3){
                    cout<<"l";
                }
            }
            else if(a[i]==6){
                if(b[i]==1){
                    cout<<"m";
                }
                if(b[i]==2){
                    cout<<"n";
                }
                if(b[i]==3){
                    cout<<"o";
                }
            }
            else if(a[i]==7){
                if(b[i]==1){
                    cout<<"p";
                }
                if(b[i]==2){
                    cout<<"q";
                }
                if(b[i]==3){
                    cout<<"r";
                }
                if(b[i]==4){
                    cout<<"s";
                }
            }
            else if(a[i]==8){
                if(b[i]==1){
                    cout<<"t";
                }
                if(b[i]==2){
                    cout<<"u";
                }
                if(b[i]==3){
                    cout<<"v";
                }
           }
           else if(a[i]==9){
                if(b[i]==1){
                    cout<<"w";
                }
                if(b[i]==2){
                    cout<<"x";
                }
                if(b[i]==3){
                    cout<<"y";
                }
                if(b[i]==4){
                    cout<<"z";
                }
           }
           else if(a[i]==0 && b[i]==1){
                cout<<" ";
           }
        }
        cout<<endl;
    }
    return 0;
}
