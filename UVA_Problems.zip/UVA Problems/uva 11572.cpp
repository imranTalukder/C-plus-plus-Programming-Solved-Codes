#include<bits/stdc++.h>
using namespace std ;

int main()
{
    long long sum,n,t,p,q,d;

    cin>>t;
    while(t--){
        cin>>sum;
        p=1+8*sum;
        q=sqrt(p);
        d=(q-1)/2;
        cout<<d<<endl;
    }
    return 0;
}
