#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long m,n;
    map<long,long>b;
    while(cin>>m>>n){
        if(m==0 && n==0){
            return 0;
        }
        long long sum=0,p,q;
        for(int i=0; i<m; i++){
            cin>>p;
            b[p]=1;
        }
        for(int i=0; i<n; i++){
            cin>>q;
            if(b[q]==1){
                sum++;
            }
        }
        b.clear();
        cout<<sum<<endl;
    }
    return 0;
}
