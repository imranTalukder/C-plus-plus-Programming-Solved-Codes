#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    while(n--){
        int x1,y1,x2,y2,r1,r2,r,len,wid,red,d;
        cin>>x1>>y1>>x2>>y2>>r1>>r2>>r;
        len=x2-x1;
        wid=y2-y1;
        red=r1-x1;
        d=r2-y1;
        if(3*len==5*wid && 5*r==len && 20*red==9*len && 2*d==wid){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}
