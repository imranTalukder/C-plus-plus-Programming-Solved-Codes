#include<bits/stdc++.h>
using namespace std;
vector<long long>G[100000];
long long cnt,p=1;
int bfs(long long s,long long ttl)
{
    long long num=0,i,k,m=1;
    queue<long long>Q;
    long visit[100000]={0};
    long long dis[100000]={0};
    Q.push(s);
    visit[s]=1;
    dis[s]=0;
    while(! Q.empty()){
        long long u=Q.front();
        Q.pop();
        for(i=0; i<G[u].size(); i++){
            long long v=G[u][i];
            if(!visit[v]){
                Q.push(v);
                visit[v]=1;
                dis[v]=dis[u]+1;
            }
        }
    }
    for(k=0; k<99990; k++){
        if(dis[k]<=ttl && dis[k] >0){
            m++;
        }
    }
    if(G[s].size()==0){
        m=0;
    }
    cout<<"Case "<<p++<<": "<<cnt-m<<" nodes not reachable from node "<<s<<" with TTL = "<<ttl<<"."<<endl;
}
int main()
{

    long long n,x,y,s,ttl,d,i;
    while(cin>>n){
        if(n==0){
            return 0;
        }
        long long total[100000]={0};
        cnt=0;
        memset(G,NULL,sizeof(G));
        for(i=0; i<n; i++){
            cin>>x>>y;
            G[x].push_back(y);
            G[y].push_back(x);
            total[x]=1;
            total[y]=1;
        }
        for(d=0; d<99990; d++){
            if(total[d]==1){
                cnt++;
            }
        }
        while(cin>>s>>ttl){
            if(s==0 && ttl==0){
                break;
            }
            bfs(s,ttl);
        }
    }
    return 0;
}
