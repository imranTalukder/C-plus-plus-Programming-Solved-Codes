#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m;
    while(cin>>n>>m){
        int coun=0;
        while(n--){
            int sum=0,k;
            for(int i=1; i<=m; i++){
                cin>>k;
                if(k==0){
                    sum=1;
                }
            }
            if(sum==0){
                coun++;
            }
        }
        cout<<coun<<endl;
    }
    return 0;

}
