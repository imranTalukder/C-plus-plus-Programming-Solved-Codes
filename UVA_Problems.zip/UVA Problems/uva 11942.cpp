#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,b,p=0;
    cin>>n;
    cout<<"Lumberjacks:"<<endl;
    while(n--){
        int k=10,m;
        cin>>m;
        for(int i=0; i<9; i++){
            cin>>b;
            if(b>=m){
               k++;
               m=b;
            }
            else if(b<=m){
                k--;
                m=b;
            }
        }
        if(k==1 || k==19){

            cout<<"Ordered"<<endl;
        }
        else{
            cout<<"Unordered"<<endl;
        }
    }

    return 0;
}
