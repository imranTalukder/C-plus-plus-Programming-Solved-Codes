#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long a,b,c,d,l,sum,i,q;
    p:
        cin>>a>>b>>c>>d>>l;
        q=0;
        if(a==0  && b==0 && c==0 && d==0 && l==0){
            return 0;
        }
        for(i=0; i<=l; i++){
            sum=a*i*i+b*i+c;
            if(sum%d==0){
                q++;
            }
        }
        cout<<q<<endl;
        goto p;
    return 0;
}
