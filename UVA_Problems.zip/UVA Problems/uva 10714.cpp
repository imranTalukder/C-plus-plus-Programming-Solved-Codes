#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--){
        int d,n,minn=0,maxx=0,k,p,q;
        cin>>d>>n;
        while(n--){
            cin>>k;
            p=min(d-k,k);
            q=max(d-k,k);
            minn=max(p,minn);
            maxx=max(q,maxx);
        }
        cout<<minn<<" "<<maxx<<endl;
    }
    return 0;
}
